import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;


public class SunshineMotto2 {

    static Scanner scanner = new Scanner(System.in);


    public static void main(String args[]) {
        int rentalTime = RentalTimeInput();
        Motto();
        computeTime(rentalTime);
    }





    public static int RentalTimeInput() {
        int time;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter the rental time (in minutes): ");
        time = scanner.nextInt();
        return time;
    }


    public static void Motto() {
        System.out.println("****************************");
        System.out.println("*Sunshine Seashores Rentals*");
        System.out.println("****************************");
    }

    public static void computeTime(int rentalTime) {
        int hoursRented = rentalTime / 60;
        int minutesRented = rentalTime - hoursRented * 60;
        final int HOURLY_RATE = 40;
        double price;

        if (minutesRented >= 40) {
            price = hoursRented * HOURLY_RATE + 40;
            System.out.println("Hours: " + hoursRented);
            System.out.println("Minutes: " + minutesRented);
            System.out.println("Total Price: $" + price);
        } else if (minutesRented < 40) {
            price = hoursRented * HOURLY_RATE + 40;
            System.out.println("Hours: " + hoursRented);
            System.out.println("Minutes: " + minutesRented);
            System.out.println("Total Price: $" + price);

        }
    }
}



